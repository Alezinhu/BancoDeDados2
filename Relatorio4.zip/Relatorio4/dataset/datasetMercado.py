dataset = [
    {
        "cliente_id": 1,
        "data_compra": "2022-03-17",
        "produtos": [
            {"descricao": "Detergente", "quantidade": 2, "preco": 4.73},
            {"descricao": "Sabão em pó", "quantidade": 1, "preco": 8.59},
            {"descricao": "Sabonete", "quantidade": 3, "preco": 1.35},
        ],
    },
    {
        "cliente_id": 2,
        "data_compra": "2022-03-16",
        "produtos": [
            {"descricao": "Laranja", "quantidade": 4, "preco": 1.99},
            {"descricao": "Carne", "quantidade": 2, "preco": 12.99},
            {"descricao": "Leite", "quantidade": 1, "preco": 3.49},
        ],
    },
    {
        "cliente_id": 3,
        "data_compra": "2022-03-15",
        "produtos": [
            {"descricao": "Mussarela", "quantidade": 1, "preco": 7.99},
            {"descricao": "Mortadela", "quantidade": 2, "preco": 6.49},
            {"descricao": "Bolacha", "quantidade": 3, "preco": 2.79},
            {"descricao": "Refrigerante", "quantidade": 2, "preco": 5.99},
        ],
    },
    {
        "cliente_id": 4,
        "data_compra": "2022-03-14",
        "produtos": [
            {"descricao": "Arroz", "quantidade": 1, "preco": 10.49},
            {"descricao": "Feijão", "quantidade": 1, "preco": 7.99},
            {"descricao": "Macarrão", "quantidade": 2, "preco": 4.29},
            {"descricao": "Mussarela", "quantidade": 1, "preco": 7.99},
            {"descricao": "Mortadela", "quantidade": 2, "preco": 6.49},
            {"descricao": "Bolacha", "quantidade": 3, "preco": 2.79},
            {"descricao": "Refrigerante", "quantidade": 2, "preco": 5.99},
        ],
    },
    {
        "cliente_id": 5,
        "data_compra": "2022-03-14",
        "produtos": [
            {"descricao": "Mussarela", "quantidade": 1, "preco": 7.99},
            {"descricao": "Mortadela", "quantidade": 2, "preco": 6.49},
            {"descricao": "Cerveja", "quantidade": 12, "preco": 2.99},
            {"descricao": "Amendoim", "quantidade": 1, "preco": 4.79},
        ],
    },
    {
        "cliente_id": 6,
        "data_compra": "2022-03-13",
        "produtos": [
            {"descricao": "Maçã", "quantidade": 3, "preco": 3.49},
            {"descricao": "Banana", "quantidade": 4, "preco": 2.99},
            {"descricao": "Tomate", "quantidade": 2, "preco": 5.99},
            {"descricao": "Feijão", "quantidade": 1, "preco": 7.99},
            {"descricao": "Macarrão", "quantidade": 2, "preco": 4.29},
            {"descricao": "Mussarela", "quantidade": 1, "preco": 7.99},
            {"descricao": "Mortadela", "quantidade": 2, "preco": 6.49},
        ],
    },
]